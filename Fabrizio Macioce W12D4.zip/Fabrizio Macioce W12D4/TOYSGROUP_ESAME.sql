-- Creazione schema --

CREATE SCHEMA Toysgroup2;

USE Toysgroup2;

create table Category (
    CategoryID int, 
    Category varchar (25),
    constraint Pk_Category primary key (CategoryID)
);

create table Region (
    RegionID int,
    Region_Name VARCHAR(25),
    constraint PK_Region primary key (RegionID)
);

create table Product (
    ProductKey int,
    CategoryID int,
    Product_Name varchar (50),
    constraint Pk_Product primary key (ProductKey),
    constraint Fk_Category_Product foreign key (CategoryID) references Category (CategoryID)
);

create table State (
    StateID INT,
    Region_Name varchar (25),
    State_Name varchar (25),
    RegionID int,
    constraint PK_State primary key (StateID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

CREATE TABLE Sales (
    Salesordernumber int,
    SalesorderNumberline int,
    Orderdate date,
    StateID int,
    ProductKey int,
    Orderquantity int,
    Unitprice decimal (10, 2),
    SalesAmount decimal (10, 2),
    constraint PK_Sales primary key (Salesordernumber),
    constraint FK_State_Sales foreign key (StateID) references State(StateID),
    constraint FK_Product_Sales foreign key (ProductKey) references Product(ProductKey)
);

 -- inserimento dati --

INSERT INTO Category (CategoryID, Category) VALUES
(1, 'Electronics'),
(2, 'Clothing'),
(3, 'Toys'),
(4, 'Books'),
(5, 'Furniture'),
(6, 'Beauty'),
(7, 'Sports'),
(8, 'Automotive'),
(9, 'Food'),
(10, 'Garden');

INSERT INTO Region (RegionID, Region_Name) VALUES
(1, 'North America'),
(2, 'South America'),
(3, 'Europe'),
(4, 'Asia'),
(5, 'Africa');

INSERT INTO Product (ProductKey, CategoryID, Product_Name) VALUES
(1, 1, 'Smartphone'),
(2, 1, 'TV'),
(3, 2, 'Gaming PC'),
(4, 2, 'Tablet'),
(5, 3, 'PS5'),
(6, 3, 'Xbox Series S'),
(7, 4, 'Nintendo Switch'),
(8, 5, 'Xbox Series X'),
(9, 6, 'GoCam'),
(10, 7, 'Iwatch');

INSERT INTO State (StateID, Region_Name, State_Name, RegionID) VALUES
(1, 'North America', 'California', 1),
(2, 'North America', 'Texas', 1),
(3, 'North America', 'New York', 1),
(4, 'South America', 'São Paulo', 2),
(5, 'South America', 'Buenos Aires', 2),
(6, 'Europe', 'Germany', 3),
(7, 'Europe', 'France', 3),
(8, 'Asia', 'Tokyo', 4),
(9, 'Asia', 'Beijing', 4),
(10, 'Africa', 'Cairo', 5),
(11, 'Africa', 'Lagos', 5);

INSERT INTO Sales (Salesordernumber, SalesorderNumberline, Orderdate, StateID, ProductKey, Orderquantity, Unitprice, SalesAmount) VALUES
(1001, 1, '2020-01-15', 3, 1, 2, 699.99, 1399.98), 
(1002, 1, '2020-02-20', 7, 3, 1, 19.99, 19.99),
(1003, 2, '2020-03-05', 2, 2, 3, 49.99, 149.97),
(1004, 3, '2020-04-12', 5, 5, 5, 25.50, 127.50),
(1005, 1, '2020-05-18', 8, 7, 1, 299.99, 299.99),
(1006, 2, '2020-06-14', 1, 10, 4, 14.99, 59.96),
(1007, 3, '2020-07-30', 6, 4, 2, 29.99, 59.98),
(1008, 4, '2020-08-10', 4, 8, 1, 799.99, 799.99),
(1009, 5, '2020-09-25', 9, 9, 3, 9.99, 29.97),
(1010, 6, '2020-10-20', 2, 6, 2, 19.99, 39.98),
(1011, 1, '2020-11-15', 11, 1, 1, 699.99, 699.99),
(1012, 2, '2020-12-05', 4, 2, 2, 49.99, 99.98),
(1013, 3, '2021-01-10', 3, 5, 3, 25.50, 76.50),
(1014, 1, '2021-02-14', 10, 3, 4, 19.99, 79.96),
(1015, 2, '2021-03-22', 5, 1, 10, 14.99, 74.95),
(1016, 1, '2021-04-18', 7, 7, 2, 299.99, 599.98),
(1017, 1, '2021-05-10', 2, 8, 1, 799.99, 799.99),
(1018, 2, '2021-06-15', 8, 4, 3, 9.99, 29.97),
(1019, 2, '2021-07-25', 3, 6, 2, 19.99, 39.98),
(1020, 1, '2021-08-30', 6, 9, 1, 49.99, 49.99),
(1021, 1, '2021-09-20', 1, 1, 2, 699.99, 1399.98),
(1022, 2, '2021-10-11', 4, 3, 1, 19.99, 19.99),
(1023, 3, '2021-11-05', 7, 2, 3, 49.99, 149.97),
(1024, 3, '2021-12-12', 10, 5, 5, 25.50, 127.50),
(1025, 1, '2022-01-22', 5, 7, 1, 299.99, 299.99),
(1026, 2, '2022-02-14', 8, 10, 4, 14.99, 59.96),
(1027, 3, '2022-03-10', 2, 4, 2, 29.99, 59.98),
(1028, 4, '2022-04-20', 9, 8, 1, 799.99, 799.99),
(1029, 5, '2022-05-15', 4, 9, 3, 9.99, 29.97),
(1030, 6, '2022-06-30', 3, 6, 2, 19.99, 39.98),
(1031, 1, '2022-07-25', 11, 1, 1, 699.99, 699.99),
(1032, 2, '2022-08-14', 6, 2, 2, 49.99, 99.98),
(1033, 3, '2022-09-18', 10, 5, 3, 25.50, 76.50),
(1034, 1, '2022-10-20', 7, 3, 4, 19.99, 79.96),
(1035, 2, '2022-11-30', 4, 10, 5, 14.99, 74.95),
(1036, 1, '2023-01-15', 9, 7, 2, 299.99, 599.98),
(1037, 1, '2023-02-25', 1, 8, 1, 799.99, 799.99),
(1038, 2, '2023-03-18', 8, 4, 3, 9.99, 29.97),
(1039, 2, '2023-04-11', 6, 6, 2, 19.99, 39.98),
(1040, 1, '2023-05-20', 3, 9, 1, 49.99, 49.99),
(1041, 1, '2023-06-22', 11, 1, 2, 699.99, 1399.98),
(1042, 2, '2023-07-15', 7, 3, 1, 19.99, 19.99),
(1043, 3, '2023-08-09', 2, 2, 3, 49.99, 149.97),
(1044, 3, '2023-09-05', 5, 5, 5, 25.50, 127.50),
(1045, 1, '2023-10-30', 10, 7, 1, 299.99, 299.99),
(1046, 2, '2023-11-12', 4, 10, 4, 14.99, 59.96),
(1047, 3, '2023-12-25', 1, 4, 2, 29.99, 59.98),
(1048, 4, '2024-01-18', 6, 8, 1, 799.99, 799.99),
(1049, 5, '2024-02-10', 9, 9, 3, 9.99, 29.97),
(1050, 6, '2024-03-25', 2, 6, 2, 19.99, 39.98);

-- 1 verifica unicità delle PK --

SELECT count(categoryID)
FROM CATEGORY
GROUP BY CategoryID;

SELECT count(Productkey)
FROM product
GROUP BY ProductKey;

select count(regionID)
from Region
group by regionID;

select count(salesordernumber)
from sales 
group by salesordernumber;

select count(stateID)
from state
group by stateID;

-- 2 esporre elenco transazioni indicando nel result il codice documento, data nome del prodotto, categoria prodotto, nome stato e nome della regione di vendita--
-- un campo boleano che in base alla condizione esprime se sono passati più di 180 gg dalla data di vendita oppure no --

select s.salesordernumber, s.orderdate, p.product_name, c.category, st.state_name, reg.region_name
,case 
when s.orderdate > date_sub(curdate(), interval 180 day) then 'True'
when s.orderdate <= date_sub(curdate(), interval 180 day) then 'False'
end as '180_days?'
from sales s 
inner join product p
on s.productkey = p.productkey
inner join category c
on p.categoryid = c.categoryid
inner join state st
on s.stateid = st.stateid
inner join region reg
on st.regionid = reg. regionid;

-- 3 esporre l'elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell'ultimo anno censito --


SELECT productKey, AVG(orderquantity) AS avgOrderQuantity
FROM sales 
WHERE YEAR(orderdate) = 2023
GROUP BY productKey
HAVING AVG(orderquantity) > (
    SELECT AVG(orderquantity) 
    FROM sales 
    WHERE YEAR(orderdate) = 2024
);

-- 4 esporre il fatturato annuo dei singoli prodotti--


select s.ProductKey, p.Product_Name,
sum(case when year(orderdate) = 2020 then salesamount else 0 end) as Fatturato2020,
sum(case when year(orderdate) = 2021 then salesamount else 0 end) as Fatturato2021,
sum(case when year(orderdate) = 2022 then salesamount else 0 end) as Fatturato2022,
sum(case when year(orderdate) = 2023 then salesamount else 0 end) as Fatturato2023,
sum(case when year(orderdate) = 2024 then salesamount else 0 end) as Fatturato2024
from sales s
inner join product p
on s.ProductKey = p.ProductKey
group by s.ProductKey, p.Product_Name;

-- 5 esporre il fatturato stato per anno ordinato per data e fatturato decrescente -- 

select year(s.orderdate) as anno, st.state_name, sum(salesamount) as fatturato
from sales s
inner join state st
on s.stateid = st.stateid
group by year (s.orderdate), st.state_Name
order by anno asc, fatturato desc;

-- 6 QUALE è LA CATEGORIA CHE HA VENDUTO DI PIU? IN QUESTO CASO NON SI GUARDA IL FATTURATO MA IL NUMERO DI QUANTITA VENDUTA PERTANTO LA RISPOSTA è:
-- electronics-

select c.Category, count(orderquantity)
from sales s
inner join product p
on s.ProductKey = p. ProductKey
inner join category c
on p.CategoryID = c.CategoryID
group by c.Category
limit 1;

-- 7 quali sono i prodotti invenduti --

-- APPROCCIO 1 con il not null vediamo se usando il left ci sono dei prodotti mai venduti in sales --
SELECT distinct product.ProductKey,
CASE 
	WHEN sales.ProductKey is not null then 'ProdottoVenduto'
    ELSE 'ProdottoInvenduto'
    end as VENDUTO
FROM product
left join sales
on product.ProductKey = sales.productkey;

-- APPROCCIO 2 con il where chiediamo di filtrare i soli prodotti invenduti chiedendo il null--
select * 
from product
left join sales
on product.ProductKey = sales.ProductKey
where SalesAmount is null;

-- 8 creazione vista sui prodotti con codice prodotto, nome prodotto, categoria --

create view Prodotti as
select p.Product_Name, p.ProductKey, c.Category
from product p 
join category c
on p.CategoryID = c.CategoryID;

select * 
from prodotti;

-- 9 creare una vista per le informazioni geografiche --

create view Informazioni_Geografiche as
select region.RegionID, region.Region_Name, state.StateID, state.State_Name
from state
inner join region
on state.RegionID = region.RegionID;

select *
from Informazioni_Geografiche